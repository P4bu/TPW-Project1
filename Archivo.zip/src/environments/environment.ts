export const environment = {

    URL:"https://pokeapi.co/api/v2/pokemon/"
};
